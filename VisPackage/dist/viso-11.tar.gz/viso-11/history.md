Useful tools to work with Visualization in Python

# Description
    
It consists of one main modules:

- `Model`: tools to work with Hists in Python

# Installation
 
## Normal installation

```bash
pip install viso
```