class Bound:
    def __init__(self, right=0,left=0):
        self.maxRight = right
        self.maxLeft = left