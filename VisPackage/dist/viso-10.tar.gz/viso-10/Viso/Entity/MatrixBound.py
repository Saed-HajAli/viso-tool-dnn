import math

class MatrixBound:
    def __init__(self):
        self.maxdMat = -999999999999
        self.maxMat = -999999999999
        self.mindMat = 999999999999
        self.minMat = 999999999999