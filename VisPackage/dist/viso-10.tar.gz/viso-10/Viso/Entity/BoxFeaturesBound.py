import math

class BoxFeaturesBound:
    def __init__(self):
        self.max = -999999999999
        self.min = 999999999999